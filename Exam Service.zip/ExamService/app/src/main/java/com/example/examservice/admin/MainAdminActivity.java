package com.example.examservice.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.examservice.R;

public class MainAdminActivity extends AppCompatActivity {

    String username ;
    TextView helloAdmin ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_main);

        Intent intent = getIntent();
        username = intent.getStringExtra("USERNAME");
        helloAdmin = findViewById(R.id.helloAdminTxtView);

        helloAdmin.setText("Hello " + username);

    }

    public void professorsToAccept(View view) {

    }

    public void allProfessors(View view) {

    }
}
