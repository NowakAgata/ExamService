package com.example.examservice.database;

public class Exam {

    String additional_information ;
    boolean learning_required;
    int max_attempts;
    int min_questions;
    String name;
    Date start_date;
    Date end_date;

    public String getAdditional_information() {
        return additional_information;
    }

    public void setAdditional_information(String additional_information) {
        this.additional_information = additional_information;
    }

    public boolean isLearning_required() {
        return learning_required;
    }

    public void setLearning_required(boolean learning_required) {
        this.learning_required = learning_required;
    }

    public int getMax_attempts() {
        return max_attempts;
    }

    public void setMax_attempts(int max_attempts) {
        this.max_attempts = max_attempts;
    }

    public int getMin_questions() {
        return min_questions;
    }

    public void setMin_questions(int min_questions) {
        this.min_questions = min_questions;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getStart_date() {
        return start_date;
    }

    public void setStart_date(Date start_date) {
        this.start_date = start_date;
    }

    public Date getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Date end_date) {
        this.end_date = end_date;
    }
}
