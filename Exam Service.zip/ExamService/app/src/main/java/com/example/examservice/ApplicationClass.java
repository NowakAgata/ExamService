package com.example.examservice;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.examservice.database.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ApplicationClass extends Application {



    static public FirebaseDatabase mDatabase ;
    static public FirebaseAuth mAuth;
    static public DatabaseReference usersRef ;
    public static final String SHARED_PREFERENCES_NAME ="examServicePreferences";
    public static final String SHARED_PREFERENCES_USERNAME_KEY = ";username;";
    public static final String SHARED_PREFERENCES_EMAIL_KEY = ";email;";
    public static final String SHARED_PREFERENCES_ROLE_KEY = ";role;";
    public static final String PROFESSOR_ROLE = "ROLE_PROFESSOR";
    public static final String STUDENT_ROLE = "ROLE_STUDENT";
    public static final String ADMIN_ROLE = "ROLE_ADMIN";
    public static final String TAG = "TAGApplicationClass" ;

    @Override
    public void onCreate() {
        super.onCreate();

        mDatabase = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();
    }

}
