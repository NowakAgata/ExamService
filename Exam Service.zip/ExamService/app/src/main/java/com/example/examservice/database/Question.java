package com.example.examservice.database;

public class Question {

}
